import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(__dirname, '..');

export const EXTENSION_DIR =
  process.env.BUSTER_EXTENSION_DIR || path.join(ROOT, 'extension');
const PROFILE_DIR = process.env.BUSTER_PROFILE_DIR || path.join(ROOT, 'profile');
const ARTIFACT_DIR = process.env.BUSTER_ARTIFACT_DIR || path.join(ROOT, 'artifacts');

/** Chromium binary used by the solver (shared with the VisionAI fallback). */
export function chromiumPath() {
  return process.env.BUSTER_CHROME_PATH || chromium.executablePath();
}

const ANCHOR_RE = /\/recaptcha\/(api2|enterprise)\/anchor/;
const BFRAME_RE = /\/recaptcha\/(api2|enterprise)\/bframe/;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const jitter = (min, max) => Math.floor(min + Math.random() * (max - min));
const stamp = () => new Date().toISOString().replace(/[:.]/g, '-');

/**
 * Solves reCAPTCHA v2 with the Buster extension.
 *
 * The browser is NOT launched through Playwright: Playwright's default
 * automation flags make reCAPTCHA refuse audio challenges ("Try again later").
 * Instead Chromium is spawned with a minimal flag set and we attach over CDP.
 */
export class BusterSolver {
  constructor(opts = {}) {
    this.headless = opts.headless ?? process.env.BUSTER_HEADLESS === 'true';
    // Fast mode is the default: skip the blind 12s wait after the checkbox
    // click and use tighter polling/pacing. Set BUSTER_FAST=false (or pass
    // fast:false per solve) for the original conservative timings.
    this.fast = opts.fast ?? process.env.BUSTER_FAST !== 'false';
    this.verbose = opts.verbose ?? true;
    this.browser = null;
    this.context = null;
    this.page = null;
    this.child = null;
    this.port = null;
    this.extensionId = null;
    this.consoleLog = [];
    this._wired = new WeakSet();
  }

  log(...args) {
    if (this.verbose) console.error('[buster]', ...args);
  }

  async launch() {
    if (this.context) return this.context;

    if (!fs.existsSync(path.join(EXTENSION_DIR, 'manifest.json'))) {
      throw new Error(`Buster extension not found at ${EXTENSION_DIR} (missing manifest.json)`);
    }

    fs.mkdirSync(PROFILE_DIR, { recursive: true });
    fs.mkdirSync(ARTIFACT_DIR, { recursive: true });

    const exe = process.env.BUSTER_CHROME_PATH || chromium.executablePath();
    if (!fs.existsSync(exe)) {
      throw new Error(
        `Chromium not found at ${exe}. Run: npx playwright install chromium (or set BUSTER_CHROME_PATH)`
      );
    }

    this.port = await freePort();
    const ext = EXTENSION_DIR;
    const args = [
      `--remote-debugging-port=${this.port}`,
      `--user-data-dir=${PROFILE_DIR}`,
      `--load-extension=${ext}`,
      `--disable-extensions-except=${ext}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--hide-crash-restore-bubble',
      '--autoplay-policy=no-user-gesture-required',
      '--window-size=1280,900',
      '--lang=en-US',
    ];

    if (this.headless) {
      args.push('--headless=new');
      args.push(
        '--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
          '(KHTML, like Gecko) Chrome/158.0.0.0 Safari/537.36'
      );
    }

    args.push('about:blank');

    this.log(`spawning chromium on port ${this.port} (headless=${this.headless})`);

    const spawnBrowser = () => {
      const child = spawn(exe, args, { stdio: 'ignore', windowsHide: false });
      child.on('exit', (code) => {
        if (this.context) this.log(`browser exited (code ${code})`);
        this.context = null;
        this.browser = null;
        this.page = null;
      });
      return child;
    };

    this.child = spawnBrowser();

    try {
      await waitForCdp(this.port, 30000);
    } catch (err) {
      // A previous server instance may have left an orphaned browser holding
      // the profile lock. Kill it and try once more.
      this.log('debug port unreachable — clearing stale browser instances for this profile');
      await killProfileBrowsers();
      try {
        this.child.kill();
      } catch {
        /* ignore */
      }
      await sleep(1500);
      this.child = spawnBrowser();
      try {
        await waitForCdp(this.port, 25000);
      } catch {
        throw err;
      }
    }

    this.browser = await chromium.connectOverCDP(`http://127.0.0.1:${this.port}`);
    this.context = this.browser.contexts()[0];
    if (!this.context) this.context = await this.browser.newContext();

    const pages = this.context.pages();
    this.page =
      pages.find((p) => p.url() === 'about:blank' && !p.isClosed()) ||
      pages.find((p) => !p.isClosed()) ||
      (await this.context.newPage());

    await this.page.setViewportSize({ width: 1280, height: 900 }).catch(() => {});

    let sw = this.context.serviceWorkers()[0];
    if (!sw) {
      sw = await this.context.waitForEvent('serviceworker', { timeout: 12000 }).catch(() => null);
    }
    this.extensionId = sw ? new URL(sw.url()).host : null;
    this.log(this.extensionId ? `extension loaded: ${this.extensionId}` : 'extension worker not seen');

    return this.context;
  }

  async ensurePage() {
    await this.launch();
    if (!this.page || this.page.isClosed()) {
      this.page = await this.context.newPage();
    }
    if (!this._wired.has(this.page)) {
      this._wired.add(this.page);
      this.page.on('console', (m) => {
        this.consoleLog.push(`[${m.type()}] ${m.text()}`);
        if (this.consoleLog.length > 200) this.consoleLog.shift();
      });
      this.page.on('pageerror', (e) => this.consoleLog.push(`[pageerror] ${e.message}`));
    }
    return this.page;
  }

  async shot(page, name) {
    try {
      const file = path.join(ARTIFACT_DIR, `${stamp()}-${name}.png`);
      await page.screenshot({ path: file });
      return file;
    } catch {
      return null;
    }
  }

  /** Read the reCAPTCHA site key from the current page, if it can be found. */
  async siteKey() {
    try {
      if (!this.page || this.page.isClosed()) return null;
      return await readSiteKey(this.page);
    } catch {
      return null;
    }
  }

  /**
   * @param {object} o
   * @param {string} [o.url]
   * @param {string} [o.clickSelector] click after load (captcha may appear only then)
   * @param {string} [o.waitForSelector]
   * @param {number} [o.timeoutMs]
   * @param {boolean} [o.headless]
   * @param {boolean} [o.fast] override the instance fast mode for this solve
   */
  async solve({ url, clickSelector, waitForSelector, timeoutMs, headless, fast } = {}) {
    const useFast = typeof fast === 'boolean' ? fast : this.fast;
    const budget = timeoutMs ?? Number(process.env.BUSTER_TIMEOUT_MS || 240000);
    const T = {
      settle: useFast ? 200 : 1200,
      clickSettle: useFast ? 300 : 1500,
      tokenAfterClick: useFast ? 800 : 12000,
      tokenNoFrame: useFast ? 2000 : 8000,
      paceMin: useFast ? 700 : 1500,
      paceMax: useFast ? 1200 : 3000,
      poll: useFast ? 250 : 700,
      audioPoll: useFast ? 400 : 900,
      audioCooldown: useFast ? 2000 : 4000,
      verifyCooldown: useFast ? 2500 : 6000,
      retryMin: useFast ? 1500 : 3500,
      retryMax: useFast ? 2500 : 6000,
      retrySettle: useFast ? 400 : 1500,
      retryClickSettle: useFast ? 600 : 1500,
      workingShot: useFast ? 15000 : 30000,
    };
    if (useFast) this.log('fast mode enabled');

    if (typeof headless === 'boolean' && headless !== this.headless) {
      this.headless = headless;
      await this.close();
    }

    const page = await this.ensurePage();
    const started = Date.now();
    const deadline = started + budget;
    const artifacts = [];
    const attempts = [];
    this.consoleLog.length = 0;

    let token = null;
    let lastFailure = null;

    for (let pass = 1; pass <= 3; pass++) {
      if (Date.now() >= deadline - 5000) break;

      if (pass > 1) {
        this.log(`captcha refused — retrying whole challenge (pass ${pass}/3)`);
        attempts.push({ at: Date.now() - started, step: 'retry-pass', pass });
        await sleep(jitter(T.retryMin, T.retryMax));
        await page
          .goto(url || page.url(), { waitUntil: 'domcontentloaded', timeout: 60000 })
          .catch(() => {});
        await sleep(T.retrySettle);
        if (waitForSelector) {
          await page.waitForSelector(waitForSelector, { timeout: 20000 }).catch(() => {});
        }
        if (clickSelector) {
          await page
            .locator(clickSelector)
            .first()
            .click({ timeout: 20000 })
            .catch(() => {});
          await sleep(T.retryClickSettle);
        }
      } else if (url) {
        this.log(`navigating to ${url}`);
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
        await sleep(T.settle);
        artifacts.push(await this.shot(page, '01-loaded'));

        if (waitForSelector) {
          await page.waitForSelector(waitForSelector, { timeout: 30000 }).catch(() => {});
        }
        if (clickSelector) {
          this.log(`clicking ${clickSelector}`);
          await page
            .locator(clickSelector)
            .first()
            .click({ timeout: 20000 })
            .catch((e) => this.log(`clickSelector failed: ${e.message}`));
          await sleep(T.clickSettle);
        }
      }

      token = await readToken(page);
      const anchor = await findFrame(page, ANCHOR_RE, token ? 1000 : 25000);

      if (!token && !anchor) {
        return this.finish(page, {
          ok: false,
          reason: 'no_widget',
          detail:
            'No reCAPTCHA v2 widget found. Buster only handles reCAPTCHA (checkbox/audio); ' +
            'it cannot solve hCaptcha, Cloudflare Turnstile, or invisible reCAPTCHA v3.',
          started,
          artifacts,
          attempts,
        });
      }

      if (!token) {
        this.log('clicking reCAPTCHA checkbox');
        try {
          await anchor.locator('#recaptcha-anchor').first().click({ timeout: 15000 });
        } catch {
          await anchor.locator('.recaptcha-checkbox-border').first().click({ timeout: 15000 });
        }
        token = await waitForToken(page, T.tokenAfterClick);
        artifacts.push(await this.shot(page, `02-checkbox-p${pass}`));
      }

      if (token) break;

      const bframe = await findVisibleBframe(page, 20000);
      if (!bframe) {
        token = await waitForToken(page, T.tokenNoFrame);
        if (token) break;
        lastFailure = {
          reason: 'no_challenge',
          detail:
            'Checkbox clicked but no challenge frame and no token appeared. The site may ' +
            'use a captcha implementation Buster does not support.',
        };
        continue;
      }

      const holder = bframe.locator('.help-button-holder').first();
      const hasHolder = await holder
        .waitFor({ state: 'attached', timeout: 20000 })
        .then(() => true)
        .catch(() => false);

      if (!hasHolder) {
        return this.finish(page, {
          ok: false,
          reason: 'extension_missing',
          detail: 'Buster did not inject its solver button; the extension failed to load.',
          started,
          artifacts,
          attempts,
        });
      }

      artifacts.push(await this.shot(page, `03-challenge-p${pass}`));

      // Pacing: instant audio requests look automated and get refused.
      await sleep(jitter(T.paceMin, T.paceMax));
      await page.mouse.move(jitter(300, 900), jitter(250, 700)).catch(() => {});

      let lastSrc = null;
      let lastClickAt = 0;
      let lastVerifyAt = 0;
      let lastShot = 0;
      let roundStart = 0;
      let lastReloadAt = 0;
      let reloads = 0;
      let blocked = null;

      while (Date.now() < deadline) {
        token = await readToken(page);
        if (token) break;

        const frame = page.frames().find((f) => BFRAME_RE.test(f.url()));
        if (!frame) {
          await sleep(T.poll);
          continue;
        }

        blocked = await detectBlocked(frame);
        if (blocked) break;

        const state = await frameState(frame);

        // Open the audio challenge with a *trusted* click. Leaving this to
        // Buster (synthetic event) is what triggers "Try again later".
        if (state.hasAudioButton && !state.audioSrc) {
          if (Date.now() - lastClickAt > T.audioCooldown) {
            lastClickAt = Date.now();
            const ok = await trustedClick(frame, '#recaptcha-audio-button');
            attempts.push({ at: Date.now() - started, step: 'open-audio', ok, pass });
            this.log(`open audio challenge (${ok ? 'ok' : 'failed'})`);
          }
          await sleep(T.audioPoll);
          continue;
        }

        // New challenge round: press Buster's button (transcribe + submit).
        if (state.audioSrc && state.audioSrc !== lastSrc) {
          lastSrc = state.audioSrc;
          roundStart = Date.now();
          const ok = await clickSolverButton(frame);
          attempts.push({ at: Date.now() - started, step: 'buster-solve', ok, pass });
          this.log(`buster solve round (${ok ? 'ok' : 'failed'})`);
        }

        // Empty transcript (model warming up / bad audio) → reload and retry.
        if (
          state.audioSrc &&
          !state.answer &&
          reloads < 8 &&
          Date.now() - roundStart > 22000 &&
          Date.now() - lastReloadAt > 12000
        ) {
          lastReloadAt = Date.now();
          reloads += 1;
          roundStart = Date.now();
          const ok = await trustedClick(frame, '#recaptcha-reload-button');
          attempts.push({ at: Date.now() - started, step: 'reload-audio', ok, pass });
          this.log(`reload audio challenge #${reloads} (${ok ? 'ok' : 'failed'})`);
          await sleep(1200);
          continue;
        }

        // Buster fills #audio-response then submits synthetically; if the answer
        // is still sitting there, submit it with a trusted click.
        if (
          state.answer &&
          state.hasVerify &&
          Date.now() - lastVerifyAt > T.verifyCooldown &&
          Date.now() - lastClickAt > T.verifyCooldown
        ) {
          lastVerifyAt = Date.now();
          const ok = await trustedClick(frame, '#recaptcha-verify-button');
          attempts.push({ at: Date.now() - started, step: 'verify', ok, pass });
          this.log(`trusted verify (${ok ? 'ok' : 'failed'})`);
        }

        if (Date.now() - lastShot > T.workingShot) {
          lastShot = Date.now();
          artifacts.push(await this.shot(page, '05-working'));
        }

        await sleep(T.poll);
      }

      if (!token) token = await readToken(page);
      if (token) break;

      if (blocked) {
        lastFailure = { reason: 'blocked', detail: blocked };
        artifacts.push(await this.shot(page, `04-blocked-p${pass}`));
        continue; // retry whole challenge
      }

      lastFailure = {
        reason: 'timeout',
        detail:
          'No token before timeout. Check artifacts: the audio challenge may not be ' +
          'offered for this IP, or the speech model could not be downloaded on first run.',
      };
      break;
    }

    if (!token) token = await readToken(page);
    artifacts.push(await this.shot(page, token ? '06-solved' : '06-timeout'));

    const result = await this.finish(page, {
      ok: Boolean(token),
      token,
      reason: token ? undefined : lastFailure?.reason || 'timeout',
      detail: token ? undefined : lastFailure?.detail,
      started,
      artifacts,
      attempts,
    });
    return { ...result, fast: useFast };
  }

  async finish(page, { ok, token, reason, detail, started, artifacts, attempts }) {
    let title = null;
    let finalUrl = null;
    let cookies = [];
    try {
      title = await page.title();
      finalUrl = page.url();
      cookies = await this.context.cookies([finalUrl]).catch(() => []);
    } catch {
      /* ignore */
    }

    return {
      ok,
      token: token || null,
      tokenLength: token ? token.length : 0,
      reason,
      detail,
      url: finalUrl,
      title,
      extensionId: this.extensionId,
      elapsedMs: Date.now() - started,
      attempts,
      artifacts: artifacts.filter(Boolean),
      cookies,
      console: this.consoleLog.slice(-25),
    };
  }

  async status() {
    let title = null;
    let url = null;
    try {
      title = this.page && !this.page.isClosed() ? await this.page.title() : null;
      url = this.page && !this.page.isClosed() ? this.page.url() : null;
    } catch {
      /* ignore */
    }
    return {
      running: Boolean(this.context),
      headless: this.headless,
      extensionId: this.extensionId,
      url,
      title,
      profileDir: PROFILE_DIR,
      artifactDir: ARTIFACT_DIR,
      port: this.port,
    };
  }

  async close() {
    try {
      if (this.browser) await this.browser.close();
    } catch {
      /* ignore */
    }
    this.browser = null;
    this.context = null;
    this.page = null;
    this.extensionId = null;

    if (this.child && this.child.pid) {
      try {
        if (process.platform === 'win32') {
          spawn('taskkill', ['/pid', String(this.child.pid), '/T', '/F'], { stdio: 'ignore' });
        } else {
          this.child.kill('SIGKILL');
        }
      } catch {
        /* ignore */
      }
      this.child = null;
    }
  }
}

/* ------------------------------- helpers ------------------------------- */

function freePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.unref();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const { port } = srv.address();
      srv.close(() => resolve(port));
    });
  });
}

async function waitForCdp(port, timeoutMs) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/json/version`);
      if (res.ok) return;
    } catch {
      /* not up yet */
    }
    await sleep(300);
  }
  throw new Error(
    'Chromium did not expose its debugging port. The profile may be locked by another ' +
      'instance (close stray Chrome/Chromium windows) or the extension failed to load.'
  );
}

/**
 * Kill browser processes started with our profile directory, so an orphaned
 * instance from a previous MCP server cannot lock the profile.
 */
async function killProfileBrowsers() {
  try {
    if (process.platform === 'win32') {
      const ps =
        `Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | ` +
        `Where-Object { $_.CommandLine -like '*${PROFILE_DIR}*' } | ` +
        `ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`;
      spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
        stdio: 'ignore',
        timeout: 20000,
      });
    } else {
      spawnSync('pkill', ['-f', PROFILE_DIR], { stdio: 'ignore', timeout: 10000 });
    }
  } catch {
    /* best effort */
  }
}

async function findFrame(page, re, timeoutMs) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    const f = page.frames().find((fr) => re.test(fr.url()));
    if (f) return f;
    await sleep(300);
  }
  return null;
}

async function findVisibleBframe(page, timeoutMs) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    const frame = page.frames().find((f) => BFRAME_RE.test(f.url()));
    if (frame) {
      try {
        const el = await frame.frameElement();
        const box = el ? await el.boundingBox() : null;
        if (box && box.width > 10 && box.height > 10) return frame;
      } catch {
        /* detached */
      }
    }
    await sleep(300);
  }
  return null;
}

async function frameState(frame) {
  try {
    return await frame.evaluate(() => {
      const audio = document.querySelector('audio#audio-source');
      const answer = document.querySelector('#audio-response');
      const audioBtn = document.querySelector('#recaptcha-audio-button');
      const verify = document.querySelector('#recaptcha-verify-button');
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      };
      return {
        audioSrc: audio && audio.src ? audio.src : null,
        answer: answer && answer.value ? answer.value : null,
        hasAudioButton: visible(audioBtn),
        hasVerify: visible(verify),
      };
    });
  } catch {
    return { audioSrc: null, answer: null, hasAudioButton: false, hasVerify: false };
  }
}

export async function readSiteKey(page) {
  try {
    return await page.evaluate(() => {
      const el = document.querySelector('[data-sitekey]');
      if (el) {
        const key = el.getAttribute('data-sitekey');
        if (key) return key.trim();
      }
      for (const iframe of document.querySelectorAll('iframe')) {
        const src = iframe.src || '';
        if (!/recaptcha/i.test(src)) continue;
        const match = src.match(/[?&]k=([^&]+)/);
        if (match) return decodeURIComponent(match[1]);
      }
      return null;
    });
  } catch {
    return null;
  }
}

export async function readToken(page) {
  try {
    return (
      (await page.evaluate(() => {
        const els = [
          document.querySelector('#g-recaptcha-response'),
          ...document.querySelectorAll('textarea[name="g-recaptcha-response"]'),
          ...document.querySelectorAll('textarea[id^="g-recaptcha-response"]'),
        ].filter(Boolean);
        for (const el of els) if (el.value && el.value.length > 20) return el.value;
        try {
          if (window.grecaptcha && typeof window.grecaptcha.getResponse === 'function') {
            const r = window.grecaptcha.getResponse();
            if (r && r.length > 20) return r;
          }
        } catch {
          /* ignore */
        }
        return null;
      })) || null
    );
  } catch {
    return null;
  }
}

async function waitForToken(page, timeoutMs) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    const token = await readToken(page);
    if (token) return token;
    await sleep(350);
  }
  return null;
}

async function trustedClick(frame, selector) {
  try {
    await frame.locator(selector).first().click({ timeout: 6000 });
    return true;
  } catch {
    return false;
  }
}

/**
 * Buster renders #solver-button inside a *closed* shadow root attached to
 * .help-button-holder, so the host element is the only reachable target.
 * A Playwright click on it is a trusted event that lands on the 48x48 button.
 */
async function clickSolverButton(frame) {
  const holder = frame.locator('.help-button-holder').first();
  try {
    await holder.click({ timeout: 5000 });
    return true;
  } catch {
    /* coordinate fallback */
  }
  try {
    const handle = await holder.elementHandle({ timeout: 3000 });
    if (!handle) return false;
    const box = await handle.boundingBox();
    if (!box || box.width === 0 || box.height === 0) return false;
    await frame.page().mouse.click(box.x + box.width / 2, box.y + box.height / 2);
    return true;
  } catch {
    return false;
  }
}

async function detectBlocked(frame) {
  try {
    return await frame.evaluate(() => {
      const text = document.body ? document.body.innerText : '';
      const m = text.match(
        /Try again later|automated queries|Your computer or network may be sending/i
      );
      if (m) return `reCAPTCHA refused the challenge: "${m[0]}". The client is flagged as automated.`;
      if (document.querySelector('.rc-doscaptcha-header')) {
        return 'reCAPTCHA served a "doscaptcha" block page instead of a challenge.';
      }
      const err = document.querySelector('.rc-audiochallenge-error-message');
      if (err && err.offsetParent !== null && err.innerText.trim()) {
        return `Audio challenge error: ${err.innerText.trim()}`;
      }
      return null;
    });
  } catch {
    return null;
  }
}
