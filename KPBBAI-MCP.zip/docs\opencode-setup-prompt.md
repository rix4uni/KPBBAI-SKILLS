# One-Prompt Setup

Give the user `KPBBAI-MCP.zip` and this prompt. They paste the prompt into a
**new OpenCode chat** and send it. OpenCode extracts the archive, installs Node
dependencies and Playwright Chromium, verifies a solve, and registers the MCP
servers.

After the agent finishes, the user must **quit and reopen OpenCode** so the new
MCP servers are loaded.

---

## The prompt (copy everything in this block)

```text
You are setting up a local reCAPTCHA v2 solver on this computer. Work through the steps in order, run the commands yourself, and report what happened. Stop and ask me only if a step fails in a way you cannot fix.

Context:
- A ZIP named `KPBBAI-MCP.zip` contains the ready-to-run project.
- The Buster extension is already included in `extension/`; do not download it.
- The solver uses Playwright's own Chromium, not my installed browser.
- Three MCP servers will be registered: `buster` (local), `tempmail` (remote), and `burp` (remote, requires Burp Suite running).
- Target folder: `%USERPROFILE%\captcha-buster` on Windows, `~/captcha-buster` on macOS/Linux.
- OpenCode config: `%USERPROFILE%\.config\opencode\opencode.json` on Windows, `~/.config/opencode/opencode.json` on macOS/Linux.

Step 1 - Find and extract the archive
- Search `Downloads` and `Desktop` for `KPBBAI-MCP.zip`.
- If there are multiple, use the newest and say which one.
- If none exist, stop and ask me for the full path.
- Extract so the target folder directly contains `package.json`, `src/`, `extension/`, and `docs/`.
- If the archive has a top-level folder, move its contents up.
- If the target already exists, do not delete it; extract to `<target>-2` and use that path.
- Verify `<project>/extension/manifest.json` exists. If not, stop and report.

Step 2 - Check Node.js
- Run `node -v` and `npm -v`. Node must be 20 or newer.
- If Node is missing or too old:
  - Windows: try `winget install --id OpenJS.NodeJS.LTS -e --silent --accept-package-agreements --accept-source-agreements`.
  - macOS: if `brew` exists, run `brew install node`.
  - Linux: use the distro package manager only if it provides Node 20+.
  - If installation needs admin rights or yields an old version, stop and tell me to install Node LTS from https://nodejs.org/.
- Refresh PATH or use the absolute node path if needed, then re-check.

Step 3 - Install dependencies
- Change into the project folder.
- Run `npm install`.
- Run `npx playwright install chromium`. On Linux, if it fails due to missing system libraries, run `npx playwright install --with-deps chromium`.
- If either command fails, stop and show me the exact error.

Step 4 - Verify the solver from the CLI
- Run `node src/cli.js https://www.google.com/recaptcha/api2/demo --json --timeout 300`.
- The first run may download the speech model; allow up to 90 seconds.
- Success means the JSON contains `"ok": true` and `tokenLength` greater than 2000.
- If it fails:
  - `extension_missing`: re-check the manifest path from step 1.
  - `blocked`: report the challenge refusal; do not loop.
  - timeout: rerun once with `--timeout 300`.
- Do not continue to MCP setup until this passes.

Step 5 - Register the MCP servers in OpenCode
- Back up the config if it exists to `opencode.json.bak-<timestamp>`.
- If the config does not exist, create it with `{"mcp":{"servers":{}}}`.
- If the file is JSONC (has comments) or invalid JSON, stop and show me the parse error; do not overwrite it.
- Merge (do not replace) these entries into `mcp.servers`:

  "buster": {
    "type": "local",
    "command": ["node", "<ABSOLUTE_PROJECT_PATH>/src/mcp-server.js"],
    "environment": { "BUSTER_HEADLESS": "false" },
    "timeout": { "startup": 60000 }
  },
  "tempmail": {
    "type": "remote",
    "url": "https://api.tempmail.cfd/mcp"
  },
  "burp": {
    "type": "remote",
    "url": "http://127.0.0.1:9876/mcp",
    "timeout": { "startup": 60000 }
  }

- Replace `<ABSOLUTE_PROJECT_PATH>` with the real project path, using forward slashes.
- The same template is in `docs/mcp-config-example.json`.
- Use `node` from PATH if it works from a GUI app; otherwise use the absolute node path from `where.exe node` (Windows) or `which node`.
- If a `buster` entry already exists, update it to the values above. If `tempmail` or `burp` already exists, leave it unchanged and report that.
- Keep every other MCP server and setting unchanged.
- Write pretty JSON and validate it with:
  `node -e "JSON.parse(require('fs').readFileSync(process.argv[1],'utf8'))" <config-file>`

Step 6 - Prepare Burp (the config entry is added even if Burp is not installed)
- The `burp` MCP server is remote. It only works when Burp Suite is running with the MCP Server extension enabled at `127.0.0.1:9876`.
- Check whether port 9876 is listening.
- If it is listening, report "Burp MCP endpoint detected" and continue.
- If it is not listening, try to start Burp Suite:
  - Windows: find the newest Burp Suite shortcut under the Start Menu or a `BurpSuiteProfessional.vbs` / `.bat` under common install folders, and launch it.
  - macOS: if `/Applications/Burp Suite Professional.app` or `/Applications/Burp Suite Community Edition.app` exists, open it with `open -a`.
  - Linux: if `burpsuite` is on PATH, start it.
- Wait up to 90 seconds for port 9876 to listen.
- If it still is not listening, do not download Burp or random JAR files. Tell me:
  - Burp Suite must be installed and open.
  - In Burp: Extender -> BApp Store -> install "MCP Server"; then open the MCP tab and enable the server (default `127.0.0.1:9876`).
  - The `burp` entry is already in the config and will connect after OpenCode restarts with Burp running.
- A tested copy of the extension is already in the project at `burp-extension/burp-mcp-all.jar` (v1.4.0). If the BApp Store is unavailable, tell me to load it via Extender -> Extensions -> Add -> Java. It requires Burp 2026.x or newer.
- Full manual steps are in `docs/burp-setup.md`.
- Do not block the rest of the setup on Burp. If it cannot be started, continue and report the manual step.

Step 7 - Report and hand off
- Summarize: project path, Node and npm versions, Playwright Chromium status, CLI result (`ok`, `fast`, `elapsedMs`, `tokenLength`), config path, backup path, and confirm `buster`, `tempmail`, and `burp` are present.
- State whether port 9876 was detected; if not, include the manual Burp step.
- Do not print the full token.
- Tell me to quit and reopen OpenCode completely.
- After the restart, tell me to ask: `Use buster_solve_captcha on https://www.google.com/recaptcha/api2/demo with headless false.`, to verify the tempmail tools, and to test `burp` with `base64_encode` on `test`.
- Do not claim the MCP tools are live until after the restart.

Rules:
- Use absolute paths.
- Do not delete or modify unrelated files or other MCP entries.
- If a step fails, stop at that step and report the exact command and error.
```

---

## What the user should see

1. The archive extracted to `captcha-buster`.
2. `npm install` and Playwright Chromium installed.
3. A demo solve returning `ok: true` (first run may take longer).
4. `buster`, `tempmail`, and `burp` added to `opencode.json`, with a backup of the old file.
5. Burp started if it is installed; otherwise a short manual step for installing/enabling the MCP Server BApp.
6. A request to restart OpenCode.

## If the agent cannot find the ZIP

Tell the user to right-click the ZIP and copy its full path, then replace
`KPBBAI-MCP.zip` in the prompt with that path. Everything else stays the same.

## Manual verification after restart

Ask OpenCode:

```text
Use buster_solve_captcha on https://www.google.com/recaptcha/api2/demo with headless false. Report ok, fast, elapsedMs, and tokenLength only.
```

Expected: `ok: true`, `fast: true`, `elapsedMs` around 4,000–8,000, and
`tokenLength` above 2,000.

Then ask:

```text
List the tempmail MCP tools.
```

Expected: the disposable-email tools (`create_inbox`, `list_emails`,
`wait_for_email`, `open_link`, `extend_inbox`, `delete_inbox`, etc.). The
`tempmail` server is remote, so it needs internet access to
`https://api.tempmail.cfd/mcp` but no local installation.

Then, with Burp running:

```text
Use burp base64_encode with content "test".
```

Expected: `dGVzdA==`. If the burp tools are missing, Burp is not running, the
MCP Server BApp is not enabled, or nothing is listening on `127.0.0.1:9876`.
Burp Suite is a separate product and is not included in the ZIP; users must
install it and enable the MCP Server BApp.

If a tool is missing, re-check the config path, JSON validity, and that
OpenCode was fully restarted.
