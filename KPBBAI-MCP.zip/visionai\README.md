# VisionAI fallback (reCAPTCHA v2 images)

This is the image-based fallback used when the Buster audio solver fails.

- Buster is always tried first (fast, ~4–8 s).
- If Buster fails, the MCP starts this Python solver.
- VisionAI is **v2 image challenges only**. The upstream v3 claim did not work
  in testing and is not used here.

## Install

Requires **Python 3.10+** and a Chromium browser.

Windows:

```powershell
cd ..
python -m venv .venv-visionai
.\.venv-visionai\Scripts\python.exe -m pip install --upgrade pip
.\.venv-visionai\Scripts\pip.exe install -r visionai\requirements.txt
.\.venv-visionai\Scripts\python.exe visionai\runner.py --self-test --url https://example.com --output visionai-selftest.json
```

macOS/Linux:

```bash
cd ..
python3 -m venv .venv-visionai
./.venv-visionai/bin/python -m pip install --upgrade pip
./.venv-visionai/bin/pip install -r visionai/requirements.txt
./.venv-visionai/bin/python visionai/runner.py --self-test --url https://example.com --output visionai-selftest.json
```

The MCP auto-detects `.venv-visionai` in the project root. Override with
`VISIONAI_PYTHON` if you install elsewhere.

## First run

The first image solve downloads:

- `yolo12x.pt` (~114 MB) from Ultralytics
- the ONNX classification model from Hugging Face

Allow 2–3 minutes for the first fallback. Later solves are much faster, but
still typically **30–90 s** on CPU.

## Standalone use

```powershell
.\.venv-visionai\Scripts\python.exe visionai\runner.py `
  --url https://www.google.com/recaptcha/api2/demo `
  --timeout 180 `
  --output result.json
```

The runner writes one JSON object to `--output`; it does not print the token to
stdout.

## Caveats

- **v2 only.** No v3 score solving, hCaptcha, or Turnstile.
- Heavy install: PyTorch, Ultralytics, OpenCV, ONNX Runtime.
- CPU inference is slow; a GPU helps if available.
- The upstream replica starts a temporary local HTTPS/HTTP server on
  `0.0.0.0`. Run it in an isolated environment.
- The default path uses Chromium host-resolver rules, not the Windows hosts
  file. The hosts-file fallback is only used when an external browser is
  supplied to the upstream library.
- Use only on systems you own or are authorized to test.
