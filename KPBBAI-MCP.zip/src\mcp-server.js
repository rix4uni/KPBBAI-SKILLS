#!/usr/bin/env node
/**
 * Buster MCP server — free reCAPTCHA solving for OpenCode (and any MCP client).
 *
 * The browser is launched lazily on the first tool call and kept alive between
 * calls so a solved token and the session cookies can be reused.
 */
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import { BusterSolver } from './buster.js';

const solver = new BusterSolver({
  headless: process.env.BUSTER_HEADLESS !== 'false',
  verbose: process.env.BUSTER_VERBOSE !== 'false',
});

const server = new McpServer(
  { name: 'buster-captcha', version: '1.0.0' },
  {
    instructions:
      'Solves reCAPTCHA v2 challenges (checkbox + audio) using the open-source Buster ' +
      'extension loaded into a real Chromium instance. Call solve_captcha with the page ' +
      'URL; it returns the g-recaptcha-response token, cookies, and screenshots. ' +
      'The browser stays open between calls (persistent profile), so logins survive. ' +
      'Only reCAPTCHA is supported — not hCaptcha, Cloudflare Turnstile, or invisible v3. ' +
      'This is a best-effort accessibility tool: Google can block audio challenges for ' +
      'flagged IPs, in which case the tool returns reason="blocked". ' +
      'Fast mode is on by default (~6-8s per solve); pass fast:false for the original conservative timings.',
  }
);

const json = (obj) => ({
  content: [{ type: 'text', text: JSON.stringify(obj, null, 2) }],
  isError: obj.ok === false,
});

server.registerTool(
  'solve_captcha',
  {
    title: 'Solve reCAPTCHA with Buster',
    description:
      'Open a URL in a Chromium window with the Buster extension, click the reCAPTCHA ' +
      'checkbox, trigger Buster\'s audio-challenge solver, and return the resulting ' +
      'token. Use clickSelector when the captcha only appears after clicking a button. ' +
      'If url is omitted, tries the already-open page.',
    inputSchema: {
      url: z.string().url().optional().describe('Page URL containing the reCAPTCHA'),
      clickSelector: z
        .string()
        .optional()
        .describe('CSS selector to click after load (e.g. a "Sign in" button that reveals the captcha)'),
      waitForSelector: z
        .string()
        .optional()
        .describe('CSS selector to wait for after navigation'),
      timeoutSeconds: z
        .number()
        .int()
        .min(10)
        .max(900)
        .optional()
        .describe('Max seconds to keep trying (default 240; first run downloads the speech model)'),
      headless: z
        .boolean()
        .optional()
        .describe('Run without a visible window (default: from BUSTER_HEADLESS env, else true)'),
      fast: z
        .boolean()
        .optional()
        .describe(
          'Fast mode: skip the blind 12s wait after the checkbox click and tighten polling/pacing ' +
            '(about 7s instead of 18s). Defaults to the BUSTER_FAST env, enabled unless it is "false".'
        ),
      closeBrowser: z
        .boolean()
        .optional()
        .describe('Close the browser after solving (default false: keep session alive)'),
    },
  },
  async ({ url, clickSelector, waitForSelector, timeoutSeconds, headless, fast, closeBrowser }) => {
    try {
      const result = await solver.solve({
        url,
        clickSelector,
        waitForSelector,
        timeoutMs: timeoutSeconds ? timeoutSeconds * 1000 : undefined,
        headless,
        fast,
      });
      if (closeBrowser) await solver.close();
      return json({
        ok: result.ok,
        token: result.token,
        tokenLength: result.token ? result.token.length : 0,
        reason: result.reason,
        detail: result.detail,
        url: result.url,
        title: result.title,
        fast: result.fast,
        elapsedMs: result.elapsedMs,
        attempts: result.attempts,
        artifacts: result.artifacts,
        cookies: result.cookies,
        consoleTail: result.console,
      });
    } catch (err) {
      return json({ ok: false, reason: 'exception', detail: String(err && err.stack ? err.stack : err) });
    }
  }
);

server.registerTool(
  'browser_status',
  {
    title: 'Buster browser status',
    description: 'Report whether the solver browser is running, which page is open, and the extension id.',
    inputSchema: {},
  },
  async () => json(await solver.status())
);

server.registerTool(
  'close_browser',
  {
    title: 'Close Buster browser',
    description: 'Close the persistent solver browser and free its resources.',
    inputSchema: {},
  },
  async () => {
    await solver.close();
    return json({ ok: true, closed: true });
  }
);

async function shutdown() {
  await solver.close();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

await server.connect(new StdioServerTransport());
console.error('[buster-mcp] ready (stdio)');
