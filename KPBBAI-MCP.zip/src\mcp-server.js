#!/usr/bin/env node
/**
 * KPBBAI-MCP — reCAPTCHA solving for OpenCode (and any MCP client).
 *
 * Strategy:
 *   1. Buster audio solver (fast, ~4-8s)
 *   2. VisionAI YOLO image solver (fallback, ~30-90s, v2 only)
 *
 * The Buster browser is launched lazily and kept alive between calls.
 */
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import { BusterSolver, chromiumPath } from './buster.js';
import { VisionAISolver } from './visionai.js';

const solver = new BusterSolver({
  headless: process.env.BUSTER_HEADLESS !== 'false',
  verbose: process.env.BUSTER_VERBOSE !== 'false',
});
const visionai = new VisionAISolver();

const server = new McpServer(
  { name: 'kpbbai-captcha', version: '1.1.0' },
  {
    instructions:
      'Solves reCAPTCHA v2 with a two-stage strategy. It tries Buster audio first ' +
      '(fast, about 4-8s), then falls back to VisionAI image solving if Buster fails. ' +
      'VisionAI is slower (about 30-90s, first run downloads models) and handles v2 ' +
      'image grids only; its v3 claim was not reliable in testing. Call solve_captcha ' +
      'with the page URL. Use solver="buster" or solver="visionai" to force one. ' +
      'The Buster browser stays open between calls so logins survive. ' +
      'Only reCAPTCHA v2 is supported — not hCaptcha, Cloudflare Turnstile, or invisible v3.',
  }
);

const json = (obj) => ({
  content: [{ type: 'text', text: JSON.stringify(obj, null, 2) }],
  isError: obj.ok === false,
});

const summarizeBuster = (result) =>
  result
    ? {
        ok: result.ok,
        reason: result.reason,
        detail: result.detail,
        elapsedMs: result.elapsedMs,
        attempts: result.attempts,
        fast: result.fast,
        tokenLength: result.token ? result.token.length : 0,
      }
    : null;

const summarizeVision = (result) =>
  result
    ? {
        ok: result.ok,
        reason: result.reason,
        detail: result.detail || result.error,
        errorType: result.errorType,
        elapsedMs: result.elapsedMs,
        timeTaken: result.timeTaken,
        captchaType: result.captchaType,
        attempts: result.attempts,
        siteKey: result.siteKey,
        python: result.python,
      }
    : null;

server.registerTool(
  'solve_captcha',
  {
    title: 'Solve reCAPTCHA (Buster -> VisionAI fallback)',
    description:
      'Tries the fast Buster audio solver first. If it fails and solver="auto" (default), ' +
      'runs the VisionAI YOLO image solver. Set solver="buster" or solver="visionai" to ' +
      'force one. VisionAI handles v2 image grids, is much slower, and downloads ~114 MB ' +
      'of models on first use. Use clickSelector when the captcha only appears after a click.',
    inputSchema: {
      url: z.string().url().optional().describe('Page URL containing the reCAPTCHA'),
      clickSelector: z
        .string()
        .optional()
        .describe('CSS selector to click after load (e.g. a "Sign in" button that reveals the captcha)'),
      waitForSelector: z
        .string()
        .optional()
        .describe('CSS selector to wait for after navigation'),
      timeoutSeconds: z
        .number()
        .int()
        .min(10)
        .max(900)
        .optional()
        .describe('Buster budget in seconds (default 240). VisionAI has its own timeout.'),
      visionaiTimeoutSeconds: z
        .number()
        .int()
        .min(30)
        .max(900)
        .optional()
        .describe('VisionAI solve budget in seconds (default 180), plus model-download grace.'),
      headless: z
        .boolean()
        .optional()
        .describe('Buster headless mode. VisionAI runs headful unless this is explicitly true.'),
      fast: z
        .boolean()
        .optional()
        .describe(
          'Buster fast mode: skip the blind 12s wait and tighten polling. Defaults to enabled.'
        ),
      siteKey: z
        .string()
        .optional()
        .describe('Optional reCAPTCHA site key; usually extracted automatically.'),
      solver: z
        .enum(['auto', 'buster', 'visionai'])
        .optional()
        .describe('auto (default) = Buster then VisionAI; buster = Buster only; visionai = image solver only.'),
      closeBrowser: z
        .boolean()
        .optional()
        .describe('Close the Buster browser after the attempt (default false: keep session alive).'),
    },
  },
  async ({
    url,
    clickSelector,
    waitForSelector,
    timeoutSeconds,
    visionaiTimeoutSeconds,
    headless,
    fast,
    siteKey,
    solver: mode = 'auto',
    closeBrowser,
  }) => {
    const started = Date.now();
    let buster = null;

    if (mode !== 'visionai') {
      try {
        buster = await solver.solve({
          url,
          clickSelector,
          waitForSelector,
          timeoutMs: timeoutSeconds ? timeoutSeconds * 1000 : undefined,
          headless,
          fast,
        });
      } catch (err) {
        buster = {
          ok: false,
          reason: 'exception',
          detail: String(err && err.stack ? err.stack : err),
          elapsedMs: Date.now() - started,
          attempts: [],
          artifacts: [],
          cookies: [],
          console: [],
        };
      }

      if (buster.ok || mode === 'buster') {
        if (closeBrowser) await solver.close();
        return json({
          ok: buster.ok,
          solver: 'buster',
          token: buster.token,
          tokenLength: buster.token ? buster.token.length : 0,
          reason: buster.reason,
          detail: buster.detail,
          url: buster.url,
          title: buster.title,
          fast: buster.fast,
          elapsedMs: buster.elapsedMs,
          attempts: buster.attempts,
          artifacts: buster.artifacts,
          cookies: buster.cookies,
          consoleTail: buster.console,
        });
      }
    }

    const visionUrl = buster?.url || url;
    if (!visionUrl) {
      if (closeBrowser) await solver.close();
      return json({
        ok: false,
        solver: 'none',
        reason: 'missing_url',
        detail: 'VisionAI fallback requires a URL.',
        buster: summarizeBuster(buster),
      });
    }

    let resolvedSiteKey = siteKey || null;
    const samePage =
      !url || !buster?.url || buster.url.split('#')[0] === url.split('#')[0];
    if (!resolvedSiteKey && mode !== 'visionai' && samePage) {
      resolvedSiteKey = await solver.siteKey().catch(() => null);
    }

    const vision = await visionai.solve({
      url: visionUrl,
      siteKey: resolvedSiteKey,
      timeoutMs: visionaiTimeoutSeconds ? visionaiTimeoutSeconds * 1000 : 180000,
      headless: headless === true,
      browserPath: chromiumPath(),
    });

    if (closeBrowser) await solver.close();

    if (vision.ok) {
      return json({
        ok: true,
        solver: 'visionai',
        token: vision.token,
        tokenLength: vision.token.length,
        url: vision.url || visionUrl,
        title: buster?.title,
        elapsedMs: Date.now() - started,
        buster: summarizeBuster(buster),
        visionai: summarizeVision(vision),
        cookies: vision.cookies || [],
        artifacts: buster?.artifacts || [],
      });
    }

    return json({
      ok: false,
      solver: 'none',
      reason: 'all_solvers_failed',
      detail: `Buster: ${buster?.reason || 'failed'}. VisionAI: ${
        vision.detail || vision.reason || 'failed'
      }.`,
      url: visionUrl,
      elapsedMs: Date.now() - started,
      buster: summarizeBuster(buster),
      visionai: summarizeVision(vision),
    });
  }
);

server.registerTool(
  'browser_status',
  {
    title: 'Solver status',
    description: 'Report Buster browser state and whether the VisionAI fallback is installed.',
    inputSchema: {},
  },
  async () =>
    json({
      ...(await solver.status()),
      visionai: visionai.status(),
    })
);

server.registerTool(
  'close_browser',
  {
    title: 'Close Buster browser',
    description: 'Close the persistent Buster browser and free its resources.',
    inputSchema: {},
  },
  async () => {
    await solver.close();
    return json({ ok: true, closed: true });
  }
);

async function shutdown() {
  await solver.close();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

await server.connect(new StdioServerTransport());
console.error('[kpbbai-mcp] ready (stdio)');
