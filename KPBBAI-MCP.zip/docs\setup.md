# KPBBAI-MCP Setup Guide - Buster reCAPTCHA + Playwright + Burp

This guide sets up a local reCAPTCHA v2 solver: Playwright drives a Chromium
window, the Buster extension solves the audio challenge, and an MCP server
exposes it to an AI agent (OpenCode, Claude Desktop, etc.). It also registers the
**Tempmail** remote MCP server for disposable-email test flows and the **Burp
Suite** MCP server (active when Burp is running).

Tested with Node 26, Playwright 1.65, Buster 3.4.0, on Windows 11. macOS and
Linux work too; shell differences are noted.

---

## 0. Quick start (experienced users)

```bash
node -v                 # must be 20+
npm install
npx playwright install chromium
npm run test:demo       # first run downloads the speech model
```

Then add the MCP entry from step 7, restart OpenCode, and ask the agent to call
`buster_solve_captcha` on the demo page.

---

## 1. Prerequisites

| Item | Requirement |
|---|---|
| OS | Windows 10/11, macOS 12+, or a modern Linux desktop |
| Node.js | **20 or newer** (LTS recommended; tested on 26) |
| Disk | ~500 MB free (Playwright Chromium + speech model) |
| Network | npm registry, Playwright download host, Hugging Face on first solve |
| MCP client | OpenCode (this guide) or another stdio MCP client |
| Burp Suite | Optional: Community or Professional, for the `burp` MCP entry |
| Permissions | Normal user account; no admin rights required |

You do **not** need Google Chrome installed. The solver uses Playwright's own
Chromium build.

---

## 2. Install Node.js

Download the LTS installer from <https://nodejs.org/> and install it with the
default options. On Windows, keep **"Add to PATH"** enabled.

Open a **new** terminal and check:

```powershell
node -v
npm -v
```

Expected: `v20.x` or newer.

If `node` is not found, reopen the terminal. If it still fails, reinstall Node
and make sure the PATH option was enabled.

---

## 3. Get the project

Your instructor will give you either a ZIP or a Git URL.

### Option A — ZIP from the instructor

Extract it to a short, local path, for example:

- Windows: `C:\Users\<you>\captcha-buster`
- macOS/Linux: `~/captcha-buster`

Avoid OneDrive/Google Drive-synced folders and paths with spaces — they can
cause file-lock and long-path problems.

The folder must contain:

```text
captcha-buster/
  package.json
  src/
    buster.js
    cli.js
    mcp-server.js
  extension/
    manifest.json
```

### Option B — Git

```bash
git clone <instructor-repo-url> captcha-buster
cd captcha-buster
```

---

## 4. Install dependencies

Open a terminal **inside the project folder**:

```powershell
cd C:\Users\<you>\captcha-buster
npm install
```

Then download the Chromium build Playwright uses:

```powershell
npx playwright install chromium
```

On Linux, also install the OS libraries:

```bash
npx playwright install --with-deps chromium
```

This download can take a few minutes and is separate from your normal browser.

**Checkpoint:** these folders/files should now exist:

```text
node_modules/
```

---

## 5. Add the Buster extension

The solver loads Buster as an unpacked extension. If your instructor already
included `extension/manifest.json`, skip to step 6.

Otherwise:

1. Open <https://github.com/dessant/buster/releases>.
2. Download the latest **Chrome** ZIP asset (for example `buster_3.4.0_chrome.zip`).
3. Extract it **into** the `extension/` folder.

Windows:

```powershell
Expand-Archive .\buster_3.4.0_chrome.zip -DestinationPath .\extension -Force
```

macOS/Linux:

```bash
unzip buster_3.4.0_chrome.zip -d extension
```

**Checkpoint:** this file must exist:

```powershell
Test-Path .\extension\manifest.json
# True
```

If the ZIP extracted a subfolder, move its contents up so `manifest.json` is
directly inside `extension/`, not `extension/buster/manifest.json`.

---

## 6. First solve from the CLI

Run the built-in demo test:

```powershell
npm run test:demo
```

What happens:

1. A Chromium window opens.
2. It navigates to Google's official reCAPTCHA demo.
3. It clicks "I'm not a robot".
4. It opens the audio challenge.
5. Buster downloads its speech model (**first run only**, ~30–90 s).
6. The JSON result is printed, including the token.
7. The browser closes.

Expected: `"ok": true`, `"fast": true`, a token of about 2,300–2,500
characters, and exit code 0.

```json
{
  "ok": true,
  "fast": true,
  "tokenLength": 2300,
  "elapsedMs": 4000
}
```

`elapsedMs` is normally 4,000–8,000 ms after the model is cached. A cold first
run can be slower.

For only the token, drop `--json`:

```powershell
node src/cli.js https://www.google.com/recaptcha/api2/demo --timeout 300
```

### CLI options

| Flag | Meaning |
|---|---|
| `--json` | Full JSON result instead of only the token |
| `--headless` | No visible window (less reliable) |
| `--headful` | Force a visible window (default) |
| `--timeout <sec>` | Max solve time (default 240) |
| `--keep-open` | Leave the browser open afterwards |
| `--slow` | Original conservative timings |
| `--status` | Show browser/extension status |
| `-h`, `--help` | Help |

---

## 7. Connect it to OpenCode (MCP)

The MCP server is a normal stdio server: OpenCode starts it, then the agent can
call its tools.

### 7.1 Find the config file

- Windows: `C:\Users\<you>\.config\opencode\opencode.json`
- macOS/Linux: `~/.config/opencode/opencode.json`

Create it if it does not exist.

### 7.2 Add the `buster` and `tempmail` entries

Merge both into the existing `mcp.servers` object:

```json
{
  "mcp": {
    "servers": {
      "buster": {
        "type": "local",
        "command": [
          "node",
          "C:/Users/<you>/captcha-buster/src/mcp-server.js"
        ],
        "environment": {
          "BUSTER_HEADLESS": "false"
        },
        "timeout": {
          "startup": 60000
        }
      },
      "tempmail": {
        "type": "remote",
        "url": "https://api.tempmail.cfd/mcp"
      },
      "burp": {
        "type": "remote",
        "url": "http://127.0.0.1:9876/mcp",
        "timeout": {
          "startup": 60000
        }
      }
    }
  }
}
```

Rules:

- Use the **absolute path** to `src/mcp-server.js`.
- Forward slashes (`C:/Users/...`) are fine on Windows and avoid JSON escaping.
- `tempmail` is a **remote** MCP server: no install, no API key, no local files.
- `burp` is a **remote** MCP server that requires Burp Suite running with the
  **MCP Server** BApp enabled at `127.0.0.1:9876`. Burp itself is not bundled.
- `BUSTER_HEADLESS`:
  - `"false"` → visible browser window, easiest to debug (recommended first).
  - `"true"` → hidden browser, quieter, slightly less reliable.
- If your existing config already has other servers, add only these three blocks
  inside `"servers"`; do not duplicate `"mcp"` or `"servers"`.
- If a `tempmail` or `burp` entry already exists, leave it unchanged.
- JSON has no trailing commas. Validate the file if OpenCode will not start.

### 7.3 If `node` is not on PATH for the GUI app

Some Windows setups launch GUI apps with a different PATH. Find Node:

```powershell
where.exe node
```

Then use the full path in the config:

```json
"command": [
  "C:/Program Files/nodejs/node.exe",
  "C:/Users/<you>/captcha-buster/src/mcp-server.js"
]
```

On macOS/Linux use `which node`.

### 7.4 Other MCP clients (optional)

Claude Desktop uses a different key (`mcpServers` / `args`):

```json
{
  "mcpServers": {
    "buster": {
      "command": "node",
      "args": ["C:/Users/<you>/captcha-buster/src/mcp-server.js"],
      "env": { "BUSTER_HEADLESS": "false" }
    }
  }
}
```

Do not run two clients against the same project folder at the same time — they
share `./profile` and will fight over the browser lock.

### 7.5 What the Tempmail MCP gives you

`tempmail` is a disposable-email service exposed as a remote MCP server. It is
independent of Buster and useful when a test flow needs email verification.

- URL: `https://api.tempmail.cfd/mcp`
- No installation, account, or API key.
- Requires internet access to `api.tempmail.cfd`.

Typical flow:

1. `create_inbox` → returns an address and a token (keep the token).
2. Use the address in the signup form you are testing.
3. `wait_for_email` → returns the verification code and the most likely link.
4. Enter the code, or call `open_link` with the link.
5. `extend_inbox` resets the expiry; `delete_inbox` removes it.
6. `list_emails` shows the inbox messages.

Inboxes expire automatically (about 60 minutes). The service is for testing and
throwaway signups — do not use it for accounts you need to keep.

### 7.6 The Burp Suite MCP

`burp` is a remote MCP server exposed by the **MCP Server** BApp inside Burp
Suite. The config entry is installed by this project, but Burp itself must be
installed and running.

Prerequisites:

- Burp Suite Community or Professional installed and licensed.
- The official **MCP Server** extension installed:
  - Preferred: `Extender → BApp Store → MCP Server → Install`.
  - Offline: load the bundled `burp-extension/burp-mcp-all.jar` via
    `Extender → Extensions → Add → Java`. This is version 1.4.0 and requires
    Burp 2026.x or newer.
- Open the **MCP** tab and enable the server. Default endpoint:
  `http://127.0.0.1:9876/mcp`.
- Keep Burp open while the tools are in use. A temporary project is fine.

The config entry (already included in 7.2):

```json
"burp": {
  "type": "remote",
  "url": "http://127.0.0.1:9876/mcp",
  "timeout": { "startup": 60000 }
}
```

Verify:

1. Start Burp and wait for it to finish loading.
2. Confirm port 9876 is listening.
3. Restart or reload OpenCode.
4. Ask: `Use burp base64_encode with content "test".` Expected: `dGVzdA==`.

Useful tools include `send_http1_request`, `create_repeater_tab`,
`get_proxy_http_history`, `get_scanner_issues`,
`generate_collaborator_payload`, and `output_user_options`.

Troubleshooting:

- **No MCP tab** → install the MCP Server BApp and restart Burp.
- **Port 9876 closed** → enable the server in Burp's MCP tab; check that another
  process is not using the port.
- **OpenCode shows burp Error after Burp starts** → reload the config or restart
  OpenCode; the MCP client tried to connect before Burp was listening.

Burp MCP can read proxy history and send requests. Use it only on systems you
are authorized to test. Full step-by-step instructions, including BApp
installation and troubleshooting, are in `docs/burp-setup.md`.

---

## 8. Restart and verify

1. **Quit OpenCode completely** and reopen it. MCP servers are started at launch,
   so editing the config while it runs does nothing.
2. Ask the agent:

   > Use `buster_solve_captcha` on `https://www.google.com/recaptcha/api2/demo`
   > with headless false.

Expected response:

```json
{
  "ok": true,
  "fast": true,
  "elapsedMs": 4000,
  "tokenLength": 2361
}
```

3. Ask: `List the tempmail MCP tools.` You should see `create_inbox`,
   `list_emails`, `wait_for_email`, `open_link`, `extend_inbox`, and
   `delete_inbox` (or similar).
4. With Burp running, ask: `Use burp base64_encode with content "test".`
   Expected: `dGVzdA==`.

The tool should appear as `buster_solve_captcha` (the `buster_` prefix is the
MCP server namespace). Related tools:

| Tool | Purpose |
|---|---|
| `buster_solve_captcha` | Solve and return the token |
| `buster_browser_status` | Is the browser running? Port, extension ID, URL |
| `buster_close_browser` | Close the browser and free resources |

---

## 9. Using the solver

Common parameters:

| Parameter | Use |
|---|---|
| `url` | Page containing the reCAPTCHA |
| `clickSelector` | Captcha appears only after clicking, e.g. `button[type=submit]` |
| `waitForSelector` | Wait for a page element before solving |
| `timeoutSeconds` | Raise to 300 on a cold first run |
| `fast` | `true` by default; `false` for the original conservative timing |
| `headless` | Override the config per call |
| `closeBrowser` | `false` by default so the token/session stays usable |

### Example: captcha behind a Sign in button

```json
{
  "url": "https://your-test-site.example/login",
  "clickSelector": "button[type=submit]",
  "headless": false
}
```

### Token facts

- The token is written into the page's `g-recaptcha-response` field.
- It is **single-use** and expires in about **2 minutes**.
- It is tied to the site key. Submit it from the same browser session (or verify
  it server-side with the site's secret).
- `closeBrowser: false` keeps the session, cookies, and page alive between calls.

### Fast mode

Fast mode is the default. It removes a blind 12 s wait after the checkbox click
and tightens polling; measured solve time drops from ~18 s to ~4–6 s.

Disable it only if a strict site refuses the challenge:

- MCP: `"fast": false`
- CLI: `--slow`
- Environment: `BUSTER_FAST=false`

---

## 10. Optional: Playwright + the solver browser

The MCP solves the captcha; if you also need to fill and submit the form, use the
**same** browser session. Launching a separate browser loses the token/cookies.

`buster_browser_status` returns a CDP port. Connect to it:

```js
import { chromium } from 'playwright';

const browser = await chromium.connectOverCDP('http://127.0.0.1:<port>');
const page = browser.contexts()[0].pages()[0];

await page.evaluate(() => document.querySelector('form').requestSubmit());
await page.waitForLoadState('domcontentloaded');
console.log(await page.evaluate(() => document.body.innerText));
```

Do not call `browser.close()` on a CDP connection — that closes the solver
browser. Just let the script end.

For a normal (non-captcha) Playwright project, install it the same way
(`npm i playwright`, `npx playwright install chromium`).

---

## 11. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `Executable doesn't exist ... chromium` | Playwright browser not installed | `npx playwright install chromium` |
| `extension_missing` | Buster not loaded | Check `extension/manifest.json`; re-extract; restart |
| `no_widget` | Not reCAPTCHA v2, or widget loads later | Use `clickSelector` / `waitForSelector`; v3/hCaptcha unsupported |
| `blocked` / "Try again later" | IP reputation | Wait, change network/VPN; not a code bug |
| Profile lock / port timeout | Another Chromium is using `./profile` | `buster_close_browser`, close stray windows, retry |
| burp tools missing / port 9876 closed | Burp not running, or MCP Server BApp disabled | Start Burp; Extender → BApp Store → MCP Server; enable it in the MCP tab |
| burp shows Error after Burp starts | OpenCode connected before Burp was listening | Save the config or run `/reload`; recheck, or restart OpenCode |
| MCP tool missing | Config syntax, wrong path, or no restart | Validate JSON, use absolute paths, restart OpenCode |
| MCP server exits immediately | Node/path error | Run `node src/mcp-server.js` and read stderr |
| `fast` unknown | Old server process still running | Restart OpenCode |
| First solve times out | Speech model download | `--timeout 300`, check Hugging Face access |
| Headless fails, headful works | Headless detection | Use `"headless": false` / `--headful` |
| CLI conflicts with MCP | Both use `./profile` | Close the MCP browser first, or use a separate `BUSTER_PROFILE_DIR` |

The MCP server is stdio-based. Running `node src/mcp-server.js` manually will
appear to hang — that is normal; it is waiting for JSON-RPC on stdin. Stop it
with `Ctrl+C`.

Logs and screenshots:

- Screenshots: `./artifacts/`
- Chromium profile: `./profile/`
- CLI logs: stderr, prefixed `[buster]`

---

## 12. Rules and safety

- Use this only on sites you own, lab/test environments, or for accessibility
  purposes. Solving CAPTCHAs on third-party sites can violate their terms.
- Use a **dedicated browser profile**. Do not sign into personal accounts inside
  the solver profile.
- Never share or commit `./profile/`: it contains cookies and session data.
- `./artifacts/` screenshots can contain personal data. Do not publish them.
- Buster requests broad extension permissions (`<all_urls>`, `webRequest`,
  `scripting`, `nativeMessaging`, `offscreen`). Review the extension before
  loading it.
- Respect rate limits. Repeated solves can get an IP flagged.

---

## Appendix A — Instructor packaging checklist

When preparing the KPBBAI-MCP ZIP or repo:

Include:

```text
package.json
package-lock.json
src/
extension/          (official Buster release, unmodified)
README.md
docs/
```

Exclude:

```text
node_modules/
profile/            (cookies — never distribute)
artifacts/          (screenshots — may contain personal data)
ego/                (unrelated test assets)
.git/
```

Before class:

1. Test the package on a clean VM/account with a fresh Node install.
2. Run `npm install`, `npx playwright install chromium`, `npm run test:demo`.
3. Confirm the MCP config path and Node path on the lab machines.
4. Pre-warm the speech model once if the classroom network blocks Hugging Face;
   the cache lives in the extension profile.
5. Pin versions: Node 20+, Playwright 1.65, Buster 3.4.0.

## Appendix B — What the agent sees

After a successful start, the MCP exposes:

```text
solve_captcha
browser_status
close_browser
```

A healthy demo call returns `ok: true`, `fast: true`, a 2.3–2.5 KB token, and
`elapsedMs` in the low thousands. Anything else is covered in the troubleshooting
table above.
