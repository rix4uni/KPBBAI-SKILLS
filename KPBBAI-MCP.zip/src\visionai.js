/**
 * VisionAI fallback — image-based reCAPTCHA v2 solving.
 *
 * Buster is always tried first because it is much faster. If Buster fails,
 * this wrapper runs the Python YOLO solver in `visionai/runner.py` and returns
 * its token/cookies. It is intentionally v2-only; the repo's v3 path was not
 * reliable in testing.
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { ROOT } from './buster.js';

const isWin = process.platform === 'win32';
const RUNNER = path.join(ROOT, 'visionai', 'runner.py');

function pythonCandidates() {
  const candidates = [];
  if (process.env.VISIONAI_PYTHON) candidates.push(process.env.VISIONAI_PYTHON);
  candidates.push(path.join(ROOT, '.venv-visionai', isWin ? 'Scripts/python.exe' : 'bin/python'));
  candidates.push(isWin ? 'python.exe' : 'python3', isWin ? 'python' : 'python');
  return candidates;
}

function isPathLike(value) {
  return value.includes('/') || value.includes('\\');
}

function resolvePython() {
  for (const candidate of pythonCandidates()) {
    if (!candidate) continue;
    if (!isPathLike(candidate) || fs.existsSync(candidate)) return candidate;
  }
  return isWin ? 'python.exe' : 'python3';
}

function tail(value, max = 4000) {
  const text = String(value || '');
  return text.length > max ? text.slice(-max) : text;
}

function killTree(child) {
  if (!child || child.killed) return;
  try {
    if (isWin) {
      spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore' });
    } else {
      child.kill('SIGKILL');
    }
  } catch {
    /* ignore */
  }
}

export class VisionAISolver {
  constructor(opts = {}) {
    this.python = opts.python || resolvePython();
    this.runner = opts.runner || RUNNER;
    this.lastError = null;
  }

  status() {
    return {
      available: fs.existsSync(this.runner),
      python: this.python,
      runner: this.runner,
      projectVenv: path.join(ROOT, '.venv-visionai'),
      lastError: this.lastError,
    };
  }

  async solve({ url, siteKey, timeoutMs = 180000, headless = false, browserPath, maxAttempts = 6 } = {}) {
    if (!url) {
      return { ok: false, reason: 'visionai_missing_url', detail: 'A URL is required for VisionAI.' };
    }
    if (!fs.existsSync(this.runner)) {
      return {
        ok: false,
        reason: 'visionai_not_installed',
        detail: `VisionAI runner not found at ${this.runner}`,
      };
    }

    const outFile = path.join(
      os.tmpdir(),
      `visionai-${Date.now()}-${Math.random().toString(36).slice(2)}.json`
    );

    const args = [
      this.runner,
      '--url',
      url,
      '--timeout',
      String(Math.max(30, Math.round(timeoutMs / 1000))),
      '--max-attempts',
      String(maxAttempts),
      '--output',
      outFile,
    ];
    if (siteKey) args.push('--site-key', siteKey);
    if (browserPath) args.push('--browser-path', browserPath);
    if (headless) args.push('--headless');

    const started = Date.now();
    const run = await new Promise((resolve) => {
      let stdout = '';
      let stderr = '';
      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        resolve(value);
      };

      let child;
      try {
        child = spawn(this.python, args, {
          cwd: path.join(ROOT, 'visionai'),
          windowsHide: true,
          env: { ...process.env, PYTHONUNBUFFERED: '1' },
        });
      } catch (err) {
        finish({ error: err, stdout, stderr });
        return;
      }

      const timer = setTimeout(() => {
        killTree(child);
        finish({ timedOut: true, stdout, stderr });
      }, Math.max(timeoutMs + 180000, 300000));

      child.stdout.on('data', (chunk) => {
        stdout += chunk.toString();
        if (stdout.length > 20000) stdout = stdout.slice(-20000);
      });
      child.stderr.on('data', (chunk) => {
        stderr += chunk.toString();
        if (stderr.length > 20000) stderr = stderr.slice(-20000);
      });
      child.on('error', (err) => {
        clearTimeout(timer);
        finish({ error: err, stdout, stderr });
      });
      child.on('exit', (code) => {
        clearTimeout(timer);
        finish({ code, stdout, stderr });
      });
    });

    let data = null;
    if (fs.existsSync(outFile)) {
      try {
        data = JSON.parse(fs.readFileSync(outFile, 'utf8'));
      } catch (err) {
        data = { ok: false, error: `Invalid VisionAI JSON: ${err.message}` };
      }
      try {
        fs.unlinkSync(outFile);
      } catch {
        /* ignore */
      }
    }

    const elapsedMs = Date.now() - started;
    if (!data) {
      const reason = run.timedOut
        ? 'visionai_timeout'
        : run.error
          ? 'visionai_spawn_failed'
          : 'visionai_failed';
      this.lastError = tail(run.stderr || run.error?.message || '');
      return {
        ok: false,
        reason,
        detail:
          run.error?.message ||
          `VisionAI exited ${run.code ?? 'without output'}. Check Python/venv setup.`,
        elapsedMs,
        python: this.python,
        stdoutTail: tail(run.stdout),
        stderrTail: tail(run.stderr),
      };
    }

    return {
      ...data,
      ok: Boolean(data.ok && data.token && String(data.token).length > 50),
      elapsedMs,
      python: this.python,
      stderrTail: tail(run.stderr),
    };
  }
}
