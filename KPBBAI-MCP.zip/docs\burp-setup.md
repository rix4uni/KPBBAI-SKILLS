# Burp Suite MCP - Setup

The `burp` entry in the OpenCode config connects to Burp Suite's official
**MCP Server** BApp. The config is added automatically by the setup prompt, but
**Burp Suite itself must be installed, running, and licensed separately**. It is
not bundled in the ZIP.

## 1. Install Burp Suite

Install Burp Suite Community or Professional from PortSwigger:

<https://portswigger.net/burp/communitydownload>

Open it once and finish the initial project setup. A temporary project is fine
for the MCP connection.

## 2. Install the MCP Server BApp

### Option A — BApp Store (recommended)

1. In Burp, open **Extender → BApp Store**.
2. Search for **MCP Server** (author: PortSwigger).
3. Click **Install**.
4. When prompted, allow the extension to load.

The BApp Store is the supported path and picks a version compatible with your
Burp installation.

### Option B — offline bundled JAR

The ZIP includes the tested extension at:

```text
burp-extension/burp-mcp-all.jar
```

Bundled version: **1.4.0** (SHA256
`B2514A9BDC6C1D10DA78C01289208523BB73914E0649535619A1BD7E12C4420E`).

1. In Burp, open **Extender → Extensions**.
2. Click **Add**.
3. Set **Extension type** to **Java**.
4. Select `burp-extension/burp-mcp-all.jar`.
5. Click **Next**, then **Close**.
6. Open the new **MCP** tab and enable the server.

Version note: the bundled JAR requires Burp **2026.x** or newer
(`MinPlatformVersion: 26`). If your Burp is older, use the BApp Store or update
Burp.

The `mcp-proxy-all.jar` is **not** needed for OpenCode. It is only for MCP
clients that cannot connect to a remote HTTP endpoint (stdio-only clients).

## 3. Enable the MCP server

1. Open the new **MCP** tab in Burp.
2. Enable the MCP server.
3. Confirm the endpoint. The default is:

```text
http://127.0.0.1:9876/mcp
```

4. Leave Burp open while using the tools.

A temporary project is sufficient; you do not need a saved project file.

## 4. Check the port

Windows:

```powershell
Test-NetConnection 127.0.0.1 -Port 9876
# TcpTestSucceeded : True
```

macOS/Linux:

```bash
nc -z 127.0.0.1 9876 && echo "port open"
```

If the port is closed, the MCP server is not enabled or Burp is not running.

## 5. Add the OpenCode entry

The setup prompt already merges this entry. For manual setup:

```json
"burp": {
  "type": "remote",
  "url": "http://127.0.0.1:9876/mcp",
  "timeout": { "startup": 60000 }
}
```

Put it inside `mcp.servers` in:

- Windows: `C:\Users\<you>\.config\opencode\opencode.json`
- macOS/Linux: `~/.config/opencode/opencode.json`

Then save the config and restart OpenCode (or run `/reload`).

## 6. Verify

With Burp running and OpenCode restarted:

```text
Use burp base64_encode with content "test".
```

Expected:

```text
dGVzdA==
```

You can also ask OpenCode to list the `burp` tools. A working connection exposes
tools such as:

- `send_http1_request`
- `create_repeater_tab`
- `create_repeater_tab_http2`
- `get_proxy_http_history`
- `get_proxy_http_history_regex`
- `get_scanner_issues`
- `generate_collaborator_payload`
- `get_collaborator_interactions`
- `output_user_options`
- `output_project_options`

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| No **MCP** tab in Burp | BApp not installed | Extender → BApp Store → MCP Server → Install |
| Port 9876 closed | MCP server disabled | MCP tab → enable the server |
| Port 9876 in use | Another process/Burp instance | Close the other instance or change the port in the MCP tab |
| OpenCode shows burp Error | It connected before Burp was listening | Save the config / `/reload`, or restart OpenCode |
| `burp` tools missing after restart | Burp is not running | Start Burp and wait for the MCP tab to initialize |
| Tools work but some return errors | Burp Community limitations | Collaborator/Scanner features may require Professional |

## Security

The Burp MCP server can read proxy history, send HTTP requests, create Repeater
tabs, and control parts of Burp. Use it only against systems you own or are
explicitly authorized to test. Do not point it at production systems without
permission, and do not share captured traffic or tokens.
