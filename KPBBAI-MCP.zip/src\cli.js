#!/usr/bin/env node
/**
 * Buster CLI — solve a reCAPTCHA with the Buster extension in a real browser.
 *
 *   node src/cli.js https://example.com/login
 *   node src/cli.js --url https://example.com --headless --timeout 300
 *   node src/cli.js --status
 *   node src/cli.js --help
 */
import { BusterSolver } from './buster.js';

function parseArgs(argv) {
  const out = { url: null, headless: null, timeoutMs: undefined, keepOpen: false, json: false, fast: undefined };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--url') out.url = argv[++i];
    else if (a === '--headless') out.headless = true;
    else if (a === '--headful') out.headless = false;
    else if (a === '--timeout') out.timeoutMs = Number(argv[++i]) * 1000;
    else if (a === '--keep-open') out.keepOpen = true;
    else if (a === '--fast') out.fast = true;
    else if (a === '--slow' || a === '--no-fast') out.fast = false;
    else if (a === '--json') out.json = true;
    else if (a === '--status') out.status = true;
    else if (a === '--help' || a === '-h') out.help = true;
    else if (a.startsWith('-')) {
      console.error(`Unknown option: ${a}`);
      process.exit(2);
    } else rest.push(a);
  }
  if (!out.url && rest.length) out.url = rest[0];
  return out;
}

const HELP = `
Buster captcha solver (free, open-source extension) — CLI

Usage:
  node src/cli.js <url> [options]
  node src/cli.js --status

Options:
  --url <url>        Page containing the reCAPTCHA (or pass it positionally)
  --headless         Run without a visible window (default: headful)
  --headful          Force a visible window
  --timeout <sec>    Max solve time (default 240)
  --fast             Skip the 12s post-checkbox wait (default: on)
  --slow, --no-fast  Use the original conservative timings
  --keep-open        Leave the browser open after solving
  --json             Print the full JSON result instead of just the token
  --status           Show browser/extension status of a running MCP instance
  -h, --help         Show this help

Output:
  The reCAPTCHA token on stdout (or JSON with --json).
  Screenshots and diagnostics go to ./artifacts.

The token is also already written into the page's g-recaptcha-response field,
so a form submitted from the same browser will carry it.
`;

const args = parseArgs(process.argv.slice(2));

if (args.help) {
  console.log(HELP.trim());
  process.exit(0);
}

const solver = new BusterSolver({ headless: args.headless ?? false, verbose: true });

if (args.status) {
  console.log(JSON.stringify(await solver.status(), null, 2));
  await solver.close();
  process.exit(0);
}

if (!args.url) {
  console.error('Missing URL. Run with --help for usage.');
  process.exit(2);
}

const result = await solver.solve({
  url: args.url,
  timeoutMs: args.timeoutMs,
  headless: args.headless ?? undefined,
  fast: args.fast,
});

if (args.json) {
  console.log(JSON.stringify(result, null, 2));
} else if (result.ok) {
  console.log(result.token);
} else {
  console.error(JSON.stringify(result, null, 2));
}

if (!args.keepOpen) await solver.close();

process.exit(result.ok ? 0 : 1);
