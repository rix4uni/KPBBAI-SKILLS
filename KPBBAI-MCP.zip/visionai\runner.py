"""VisionAI fallback runner — reCAPTCHA v2 image challenges only.

This is called by the Node MCP server after Buster fails. It writes one JSON
object to --output and avoids printing the token to stdout/stderr.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import tempfile
import traceback
from pathlib import Path
from urllib.parse import unquote

import requests

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
)


def find_site_key(url: str) -> str | None:
    """Best-effort site-key extraction from the HTML (no JS execution)."""
    try:
        response = requests.get(url, timeout=20, headers={"User-Agent": USER_AGENT})
        html = response.text
    except Exception:
        return None

    patterns = [
        r'data-sitekey=["\']([^"\']+)',
        r'sitekey["\']?\s*[:=]\s*["\']([^"\']+)',
        r'[?&]k=([^&"\']+)',
    ]
    for pattern in patterns:
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            return unquote(match.group(1)).strip()
    return None


def write_result(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    parser.add_argument("--site-key")
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--max-attempts", type=int, default=6)
    parser.add_argument("--output", required=True)
    parser.add_argument("--browser-path")
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    output = Path(args.output)
    tmp_dir = Path(tempfile.mkdtemp(prefix="visionai-"))

    if args.self_test:
        try:
            import onnxruntime
            import torch
            import ultralytics
            import vision_ai_recaptcha_solver

            write_result(
                output,
                {
                    "ok": True,
                    "selfTest": True,
                    "python": sys.version.split()[0],
                    "torch": torch.__version__,
                    "ultralytics": ultralytics.__version__,
                    "onnxruntime": onnxruntime.__version__,
                    "visionai": getattr(vision_ai_recaptcha_solver, "__version__", "unknown"),
                },
            )
            return 0
        except Exception as exc:
            write_result(
                output,
                {"ok": False, "selfTest": True, "error": str(exc), "errorType": type(exc).__name__},
            )
            return 0

    site_key = args.site_key or find_site_key(args.url)
    if not site_key:
        write_result(
            output,
            {
                "ok": False,
                "error": "Could not find a reCAPTCHA site key on the page. Pass siteKey explicitly.",
                "errorType": "SiteKeyNotFound",
                "url": args.url,
            },
        )
        return 0

    print(f"[visionai] solving {args.url} (site key {site_key[:12]}...)", file=sys.stderr)
    try:
        from vision_ai_recaptcha_solver import RecaptchaSolver, SolverConfig

        config = SolverConfig(
            timeout=args.timeout,
            max_attempts=args.max_attempts,
            headless=args.headless,
            browser_path=args.browser_path,
            download_dir=tmp_dir,
            cleanup_tmp_on_close=False,
            persist_html=False,
            log_level="WARNING",
        )

        with RecaptchaSolver(config) as solver:
            result = solver.solve(
                website_key=site_key,
                website_url=args.url,
                is_invisible=False,
            )
            payload = {
                "ok": True,
                "token": result.token,
                "tokenLength": len(result.token),
                "timeTaken": result.time_taken,
                "captchaType": result.captcha_type.value,
                "attempts": result.attempts,
                "siteKey": site_key,
                "cookies": result.cookies,
            }
            write_result(output, payload)
            print("[visionai] solved", file=sys.stderr)
            return 0
    except Exception as exc:
        write_result(
            output,
            {
                "ok": False,
                "error": str(exc),
                "errorType": type(exc).__name__,
                "traceback": traceback.format_exc(limit=8),
                "siteKey": site_key,
                "url": args.url,
            },
        )
        print(f"[visionai] failed: {exc}", file=sys.stderr)
        return 0
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
