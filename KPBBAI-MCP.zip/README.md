# KPBBAI-MCP — Buster audio + VisionAI image fallback

Free reCAPTCHA v2 solving for OpenCode. It tries the open-source
[Buster](https://github.com/dessant/buster) extension first (fast audio solve),
then falls back to a local YOLO image solver (VisionAI) when Buster fails.

No paid API, no account. Buster solves reCAPTCHA **audio challenges** with local
speech recognition (transformers.js + ONNX, models fetched from Hugging Face on
first use). VisionAI solves **v2 image grids** locally with Ultralytics YOLO and
ONNX models.

## Solvers

| Order | Solver | Speed | Handles |
|---|---|---|---|
| 1 | Buster audio | ~4–8 s | reCAPTCHA v2 audio |
| 2 | VisionAI images | ~30–90 s | reCAPTCHA v2 3×3 / 4×4 image grids |

`solver: "auto"` (default) tries Buster, then VisionAI. Force one with
`solver: "buster"` or `solver: "visionai"`. VisionAI is v2-only; its upstream
v3 claim did not work in testing. Install it once with
`visionai/requirements.txt` into `.venv-visionai` (see `docs/setup.md`).

## Architecture (why it looks like this)

- **Bundled Chromium, not installed Chrome.** Chrome ≥ 137 ignores
  `--load-extension`, so the extension can only be loaded by Playwright's
  Chromium.
- **Spawned with minimal flags, attached over CDP.** Playwright's default
  automation flags make reCAPTCHA return *"Try again later"* instead of an audio
  challenge. Launching Chromium ourselves with clean flags and using
  `connectOverCDP()` avoids that fingerprint.
- **Trusted clicks for the audio challenge.** Buster clicks the audio button with
  a synthetic DOM event, which reCAPTCHA can reject. The solver opens the audio
  challenge itself with a real mouse click, then lets Buster transcribe and fill
  the answer.
- **Persistent profile** at `./profile`, so cookies/logins survive between calls.
- **VisionAI fallback.** If Buster fails, the MCP runs a Python YOLO solver
  (`visionai/runner.py`) that clicks image tiles and returns the token/cookies.
- The extension's solve button lives in a **closed shadow root**; the solver
  clicks its host element (`.help-button-holder`), which reaches the button.

## CLI

```bash
# headful (default) — most reliable
node src/cli.js https://www.google.com/recaptcha/api2/demo --json

# original conservative timings (adds ~12s)
node src/cli.js https://www.google.com/recaptcha/api2/demo --slow

# headless
node src/cli.js --url https://example.com/login --headless --timeout 300

# captcha appears only after clicking "Sign in"
node src/cli.js https://example.com/login --json --timeout 240
# (use the MCP tool's clickSelector for that from an agent)
```

- Prints the token on stdout (`--json` for the full result).
- The token is also already in the page's `g-recaptcha-response` field.
- Screenshots land in `./artifacts` (useful when something fails).
- **Fast mode is on by default.** It skips the blind 12 s wait after the checkbox
  click and tightens polling. `--slow` (or `BUSTER_FAST=false`) restores the
  original timing.

## MCP (OpenCode)

Already registered in `~/.config/opencode/opencode.json` as `buster` (local,
stdio). Restart OpenCode, then the agent gets:

| Tool | Purpose |
|---|---|
| `buster_solve_captcha` | Buster first, VisionAI fallback. Params: `url`, `clickSelector`, `waitForSelector`, `timeoutSeconds`, `visionaiTimeoutSeconds`, `solver` (`auto`/`buster`/`visionai`), `siteKey`, `headless`, `fast`, `closeBrowser` → token, cookies, screenshots |
| `buster_browser_status` | Buster browser state + whether the VisionAI fallback is installed |
| `buster_close_browser` | free Buster browser resources |

Example agent call:

```
buster_solve_captcha { "url": "https://target/login", "clickSelector": "button[type=submit]" }
```

`solver` defaults to `auto`: Buster audio first, then VisionAI images if Buster
fails. VisionAI is slower and v2-only.

The Buster browser stays open between calls, so you can solve a captcha and then
have another tool submit the form in the same session. `BUSTER_HEADLESS=false` in
the config makes the window visible. VisionAI closes its browser after solving
and returns the token plus cookies.

The KPBBAI-MCP package also registers the **Tempmail** remote MCP server
(`https://api.tempmail.cfd/mcp`) for disposable-email flows and the **Burp
Suite** MCP server (`http://127.0.0.1:9876/mcp`, active when Burp is running with
the MCP Server extension enabled). The tested MCP Server extension is bundled at
`burp-extension/burp-mcp-all.jar` for offline installs. See
`docs/setup.md`, `docs/burp-setup.md`, and `docs/mcp-config-example.json`.

### Fast mode

Fast mode is enabled by default. The original flow waited **12 seconds** for a
token after clicking the checkbox before it even looked for the challenge frame;
that wait is gone. Polling is also tighter and the pre-audio "human pacing" is
shorter (700–1200 ms instead of 1500–3000 ms). The audio step itself is unchanged.

Measured on the Google demo page with a warm profile:

| Mode | Time to token |
|---|---|
| `fast: false` (original) | 17.6–20.0 s |
| `fast: true` (default) | ~6–8 s |

Overrides:

- MCP: pass `"fast": false` in the tool call.
- CLI: `--slow` (or `BUSTER_FAST=false`).
- Config: `BUSTER_FAST=false` in the server environment.

## Requirements

- Node 20+ (tested on 26)
- Playwright Chromium: `npx playwright install chromium`
- Network access to `huggingface.co` on first solve (speech model download)

Re-install/update the extension:

```powershell
# download the current chrome zip from https://github.com/dessant/buster/releases
Expand-Archive buster_..._chrome.zip -DestinationPath extension -Force
```

## Limitations (read these)

- **reCAPTCHA v2 only.** hCaptcha, Cloudflare Turnstile, and invisible reCAPTCHA
  v3 are not supported — there is no audio challenge to solve.
- Audio challenges can be **refused per IP** (`reason: "blocked"`). Residential
  IPs work far better than VPN/datacenter IPs. Changing network is the only fix.
- Solve success depends on Google not serving a harder challenge; retries and
  multiple rounds are handled, but nothing is guaranteed.
- Use this for your own accounts, accessibility, and testing. Solving captchas on
  sites you don't own may violate their terms of service.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `reason: "blocked"` | IP flagged or too many attempts; wait, or change network/VPN |
| `extension_missing` | Check `extension/manifest.json` exists; re-download the extension |
| `no_widget` | Page isn't reCAPTCHA v2, or the captcha loads in another step → use `clickSelector` |
| Profile lock / port timeout | Close stray Chromium windows, or delete `./profile` |
| First solve is slow | Speech model is downloading (~1 min); raise `--timeout` |
| Audio refused only in fast mode | Use `--slow` / `"fast": false`; the site is stricter about pacing |
| Token empty after challenge closes | Re-run; check `./artifacts` screenshots |
